code submitted by: PARTH PADALKAR. UTD ID 2021473758

language : Python2.7
library requirements:
Pandas
numpy
scikit-learn

------------------------------------------------------------------------------------------------
The program runs the algorithms one after the other

#commandline arguments:

-train_data : used to input the training directory address as a string
-test_data : used to input the testing directory address as a string

---------------------------------------------------------------------------------------------------
example command 

python text_classification.py -train_data "enron1_train/enron1/train" -test_data "enron1_test/enron1/test"



